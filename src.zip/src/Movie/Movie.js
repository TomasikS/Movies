import React from 'react';

const movie = ( props ) => {
    return (
        <div className="Movie">
            <p onClick={props.click}>{props.year}  {props.name} {props.description}     </p>
            <p>{props.children}</p>
            <input type="text" onChange={props.changed} value={props.name} />
        </div>
    )
};

export default movie;