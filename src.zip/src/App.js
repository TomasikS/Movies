import React, { Component } from 'react';
import './App.css';
import Movie from './Movie/Movie';

class App extends Component {
  state = {
    movies: [
      { name: 'Scary Movie 3', description: 'horror', year: 1999 },
      { name: 'Maly unaveny Joe', description: 'western' , year:  2000},
      { name: 'Sam doma', description: 'comedy',year:  1990 }
    ],
    otherState: 'some other value',
    visibleMovies: true
  }
  
  
  
   constructor(props){
        super(props);
        this.Change=this.Change.bind(this);
    }
	
	
	
  Change()  {
    let visible= this.state.visibleMovies;
    visible=!visible;
  }
 

   render () {
    const style = {
      backgroundColor: 'white',
      font: 'inherit',
      border: '1px solid blue',
      padding: '8px',
      cursor: 'pointer'
    };
	
	
 
	

     let movies=null;
    if(this.state.visibleMovies){
     movies=(
        <div>

   
         {this.state.movies.map( (movie,index)=> {
           return <Movie name={movie.name}
           description={movie.description}
           year={movie.year}
          />
         })};
        </div>
      );
    }
	
	
	
    return (
      <div className="App">
        
		
		
   
        
          { movies}
      </div>
    );

  }

 
}

export default App;
